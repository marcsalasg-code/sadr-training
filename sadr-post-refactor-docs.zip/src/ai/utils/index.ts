/**
 * AI Utils - Utility functions for AI operations
 */

export { mapCatalogForPrompt } from './catalogMapper';
export { mapGeneratedToSession, groupByBlock } from './responseMapper';
