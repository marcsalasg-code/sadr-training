/**
 * Core Config Module
 */
export * from './trainingConfig.model';
