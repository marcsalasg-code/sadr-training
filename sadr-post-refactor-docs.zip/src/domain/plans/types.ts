/**
 * Domain Layer - Plans
 * 
 * Pure types and business logic for training plan domain.
 * No React/Zustand dependencies.
 */

// ============================================
// TYPES
// ============================================

export interface PlannedSession {
    id: string;
    name: string;
    dayOfWeek: number; // 0-6, Sunday = 0
    templateId?: string;
    focus?: string;
    estimatedDuration?: number;
}

export interface WeekPlan {
    weekNumber: number;
    startDate: string;
    endDate: string;
    sessions: PlannedSession[];
    notes?: string;
    isDeload?: boolean;
}

export interface TrainingPlan {
    id: string;
    name: string;
    athleteId: string;
    description?: string;
    weeklyFrequency: number;
    durationWeeks: number;
    startDate: string;
    endDate: string;
    weeks?: WeekPlan[];
    goals?: string[];
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}

export interface PlanAdherence {
    plannedSessions: number;
    completedSessions: number;
    adherenceRate: number;
    currentWeek: number;
    streakDays: number;
}

// ============================================
// CALCULATIONS (Pure Functions)
// ============================================

/**
 * Calculate plan progress
 */
export function calculatePlanProgress(plan: TrainingPlan): {
    weeksCompleted: number;
    totalWeeks: number;
    progressPercent: number;
} {
    const start = new Date(plan.startDate);
    const now = new Date();
    const daysPassed = Math.floor((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    const weeksCompleted = Math.floor(daysPassed / 7);

    return {
        weeksCompleted: Math.min(weeksCompleted, plan.durationWeeks),
        totalWeeks: plan.durationWeeks,
        progressPercent: Math.round((weeksCompleted / plan.durationWeeks) * 100),
    };
}

/**
 * Calculate adherence rate
 */
export function calculateAdherence(
    plannedCount: number,
    completedCount: number
): number {
    if (plannedCount === 0) return 100;
    return Math.round((completedCount / plannedCount) * 100);
}

/**
 * Get current week of plan
 */
export function getCurrentPlanWeek(plan: TrainingPlan): number {
    const start = new Date(plan.startDate);
    const now = new Date();
    const daysPassed = Math.floor((now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    return Math.floor(daysPassed / 7) + 1;
}

/**
 * Check if plan is active (within date range)
 */
export function isPlanCurrentlyActive(plan: TrainingPlan): boolean {
    const now = new Date();
    const start = new Date(plan.startDate);
    const end = new Date(plan.endDate);
    return now >= start && now <= end && plan.isActive;
}

/**
 * Get sessions for a specific day
 */
export function getSessionsForDay(
    plan: TrainingPlan,
    date: Date
): PlannedSession[] {
    const weekNumber = getCurrentPlanWeek(plan);
    const week = plan.weeks?.find(w => w.weekNumber === weekNumber);
    if (!week) return [];

    const dayOfWeek = date.getDay();
    return week.sessions.filter(s => s.dayOfWeek === dayOfWeek);
}

/**
 * Calculate weekly volume distribution
 */
export function calculateWeeklyDistribution(
    sessions: PlannedSession[]
): Record<number, number> {
    const distribution: Record<number, number> = {
        0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0
    };

    for (const session of sessions) {
        distribution[session.dayOfWeek]++;
    }

    return distribution;
}

/**
 * Check if week is deload
 */
export function isDeloadWeek(weekNumber: number, deloadEvery = 4): boolean {
    return weekNumber > 0 && weekNumber % deloadEvery === 0;
}

/**
 * Generate week dates
 */
export function generateWeekDates(startDate: string, weekNumber: number): {
    startDate: string;
    endDate: string;
} {
    const start = new Date(startDate);
    start.setDate(start.getDate() + (weekNumber - 1) * 7);

    const end = new Date(start);
    end.setDate(end.getDate() + 6);

    return {
        startDate: start.toISOString().split('T')[0],
        endDate: end.toISOString().split('T')[0],
    };
}
