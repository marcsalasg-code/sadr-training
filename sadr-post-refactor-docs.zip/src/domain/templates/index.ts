/**
 * Domain Layer - Templates
 * Re-exports all template domain types and functions
 */

export * from './types';
