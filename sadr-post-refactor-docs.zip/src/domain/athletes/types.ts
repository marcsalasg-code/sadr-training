/**
 * Domain Layer - Athletes
 * 
 * Pure types and business logic for athlete domain.
 * No React/Zustand dependencies.
 */

// ============================================
// TYPES
// ============================================

export interface Athlete {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    birthDate?: string;
    height?: number; // cm
    weight?: number; // kg
    notes?: string;
    isActive: boolean;
    oneRMAnchors?: Record<string, number>; // exerciseId -> 1RM kg
    createdAt: string;
    updatedAt: string;
}

export interface AthleteStats {
    totalSessions: number;
    completedSessions: number;
    totalVolume: number;
    totalSets: number;
    avgSessionDuration: number;
    lastSessionDate: string | null;
    weeklyFrequency: number;
}

export interface AthleteProgress {
    volumeTrend: 'up' | 'down' | 'stable';
    frequencyTrend: 'up' | 'down' | 'stable';
    strengthTrends: Record<string, 'up' | 'down' | 'stable'>;
}

// ============================================
// CALCULATIONS (Pure Functions)
// ============================================

/**
 * Calculate athlete stats from sessions
 */
export function calculateAthleteStats(
    sessions: Array<{
        athleteId: string;
        status: string;
        totalVolume?: number;
        totalSets?: number;
        duration?: number;
        completedAt?: string;
    }>,
    athleteId: string
): AthleteStats {
    const athleteSessions = sessions.filter(s => s.athleteId === athleteId);
    const completed = athleteSessions.filter(s => s.status === 'completed');

    const totalVolume = completed.reduce((sum, s) => sum + (s.totalVolume || 0), 0);
    const totalSets = completed.reduce((sum, s) => sum + (s.totalSets || 0), 0);
    const totalDuration = completed.reduce((sum, s) => sum + (s.duration || 0), 0);

    const sortedByDate = completed
        .filter(s => s.completedAt)
        .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime());

    // Calculate weekly frequency (last 4 weeks)
    const fourWeeksAgo = new Date();
    fourWeeksAgo.setDate(fourWeeksAgo.getDate() - 28);
    const recentSessions = completed.filter(
        s => s.completedAt && new Date(s.completedAt) >= fourWeeksAgo
    );
    const weeklyFrequency = recentSessions.length / 4;

    return {
        totalSessions: athleteSessions.length,
        completedSessions: completed.length,
        totalVolume,
        totalSets,
        avgSessionDuration: completed.length > 0 ? totalDuration / completed.length : 0,
        lastSessionDate: sortedByDate[0]?.completedAt || null,
        weeklyFrequency: Math.round(weeklyFrequency * 10) / 10,
    };
}

/**
 * Determine athlete activity status
 */
export function getAthleteActivityStatus(lastSessionDate: string | null): 'active' | 'inactive' | 'new' {
    if (!lastSessionDate) return 'new';

    const daysSinceLastSession = Math.floor(
        (Date.now() - new Date(lastSessionDate).getTime()) / (1000 * 60 * 60 * 24)
    );

    return daysSinceLastSession <= 14 ? 'active' : 'inactive';
}

/**
 * Filter athletes by activity status
 */
export function filterAthletesByActivity(
    athletes: Athlete[],
    status: 'all' | 'active' | 'inactive'
): Athlete[] {
    if (status === 'all') return athletes;
    return athletes.filter(a => a.isActive === (status === 'active'));
}

/**
 * Search athletes by name/email
 */
export function searchAthletes(athletes: Athlete[], query: string): Athlete[] {
    if (!query.trim()) return athletes;
    const lower = query.toLowerCase();
    return athletes.filter(
        a => a.name.toLowerCase().includes(lower) ||
            a.email?.toLowerCase().includes(lower)
    );
}
