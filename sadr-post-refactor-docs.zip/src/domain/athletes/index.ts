/**
 * Domain Layer - Athletes
 * Re-exports all athlete domain types and functions
 */

export * from './types';
