/**
 * Settings Views
 */
export { TrainingConfigView } from './TrainingConfigView';
